"""ZLT LEGATO: servidor local para leer automáticamente .xlsx y .csv de una carpeta.
Uso: python mag_servidor.py "C:\\MAG_Datos". Requiere pip install openpyxl para .xlsx.
No conecta a PLC ni publica datos fuera de este equipo (127.0.0.1).
"""
import csv, io, json, re, sys, time, webbrowser
from datetime import datetime, date
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parent
FOLDER=Path(sys.argv[1]).expanduser().resolve() if len(sys.argv)>1 else ROOT/'DATOS_MAG'
FOLDER.mkdir(parents=True,exist_ok=True)
HTML=ROOT/'ZLT_LEGATO_MAG_Aplicacion.html'

def extract(rows):
    rows=iter(rows)
    header=next(rows,None)
    if not header: return []
    hdr=[str(x or '').strip().lower().replace(' ','') for x in header]
    def idx(aliases, default):
        return next((hdr.index(a) for a in aliases if a in hdr), default)
    a=idx(['name','nombre','senal','señal'],0)
    b=idx(['timestamp','fecha','time','datetime','fecha_hora'],1)
    c=idx(['valuenum','value','valor','valor_acumulado'],2)
    data=[]
    for row in rows:
        if len(row)<=max(a,b,c):continue
        name,stamp,val=[row[i] for i in (a,b,c)]
        if not name or stamp is None or val is None:continue
        name=str(name).strip()
        if not re.search(r'(GGH|MGH)[_\s-]*MAG\s*\d+.*Log[ií]stica\s*(Entrada|Salida)',name,re.I): continue
        if isinstance(stamp,datetime): stamp=stamp.strftime('%d/%m/%Y, %H:%M:%S')
        elif isinstance(stamp,date): stamp=stamp.strftime('%d/%m/%Y, 00:00:00')
        elif re.match(r'^\d{4}-\d{2}-\d{2}\s',str(stamp)):
            try: stamp=datetime.fromisoformat(str(stamp)).strftime('%d/%m/%Y, %H:%M:%S')
            except ValueError:pass
        if isinstance(val,str):val=val.strip().replace(',','.')
        try:val=float(val)
        except (ValueError,TypeError):continue
        data.append([name,str(stamp),str(val)])
    return data

def read_csv_file(path):
    text=path.read_text(encoding='utf-8-sig')
    if text.lower().startswith('sep='):
        text='\n'.join(text.splitlines()[1:])
    if path.suffix.lower()=='.md':
        rows=[[x.strip() for x in line.strip().strip('|').split('|')] for line in text.splitlines() if line.strip().startswith('|') and not re.match(r'^\|?[\s|:-]+$',line)]
        return extract(rows)
    sample=text[:4096]
    try:d=csv.Sniffer().sniff(sample,delimiters=';,\t|').delimiter
    except csv.Error:d=';' if ';' in sample else ','
    return extract(csv.reader(io.StringIO(text),delimiter=d))

def collect():
    files=sorted(p for p in FOLDER.iterdir() if p.is_file() and not p.name.startswith('~$') and p.suffix.lower() in ('.xlsx','.csv','.tsv','.txt','.md'))
    all_rows=[];errors=[]
    for p in files:
        try:
            if p.suffix.lower()=='.xlsx':
                try:from openpyxl import load_workbook
                except ImportError:raise RuntimeError('Instala openpyxl: python -m pip install openpyxl')
                w=load_workbook(p,read_only=True,data_only=True)
                sh=w['Datos'] if 'Datos' in w.sheetnames else w.active
                rows=extract(sh.values)
                w.close()
            else:rows=read_csv_file(p)
            all_rows.extend(rows)
        except Exception as e:errors.append(p.name+': '+str(e))
    # Dedupe por nombre, fecha y hora; el fichero más reciente vence si existen duplicados
    dedup={}
    for row in all_rows: dedup[(row[0],row[1])]=row
    modified=max([p.stat().st_mtime_ns for p in files],default=0)
    return {'ok':True,'records':list(dedup.values()),'files':len(files),'rows':len(dedup),'folder':str(FOLDER),'updated':sum(p.stat().st_mtime_ns + p.stat().st_size for p in files),'errors':errors}

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        route=urlsplit(self.path).path
        if route=='/api/records':
            try:payload=json.dumps(collect(),ensure_ascii=False).encode('utf-8')
            except Exception as e:payload=json.dumps({'ok':False,'error':str(e)}).encode('utf-8')
            mime='application/json; charset=utf-8'
        elif route in ('/','/index.html'):
            payload=HTML.read_bytes();mime='text/html; charset=utf-8'
        else:self.send_error(404);return
        self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
    def log_message(self,*args):pass

if __name__=='__main__':
    address=('127.0.0.1',8765)
    server=ThreadingHTTPServer(address,Handler)
    print('MAG Control: http://127.0.0.1:8765')
    print('Carpeta de lectura:',FOLDER)
    print('Añade archivos XLSX o CSV a esa carpeta. Refresco cada 30 segundos.')
    print('Cierra esta ventana para detener el servicio. Ctrl+C para finalizar.')
    webbrowser.open('http://127.0.0.1:8765')
    server.serve_forever()
