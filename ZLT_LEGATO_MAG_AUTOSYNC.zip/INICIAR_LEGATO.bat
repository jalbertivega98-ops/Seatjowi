@echo off
cd /d "%~dp0"
python -c "import openpyxl" >nul 2>&1 || python -m pip install openpyxl
python mag_servidor.py
pause
